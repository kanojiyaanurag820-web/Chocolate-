// Shared interactions for all four pages.
const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.textContent = isOpen ? "✕" : "☰";
  });
}

// Add-to-cart buttons are intentionally decorative, as requested.
document.querySelectorAll(".add-button").forEach((button) => {
  button.addEventListener("click", (event) => event.preventDefault());
});

// This is a front-end demo only; it does not send or save personal details.
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = document.getElementById("fullName").value.trim();
    const message = document.getElementById("formMessage");
    message.textContent = `Thanks, ${name}! This demo form is working, but no details were sent or saved.`;
    loginForm.reset();
  });
}